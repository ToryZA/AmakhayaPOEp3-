const donationForm = document.querySelector("#donation-form");
const customAmountInput = document.querySelector("#custom-amount");
const donationResult = document.querySelector("#donation-result");

customAmountInput.addEventListener("input", () => {
    if (customAmountInput.value !== "") {
        donationForm.querySelectorAll('input[name="amount"]').forEach((option) => {
            option.checked = false;
        });
    }
});

donationForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const selectedAmount = donationForm.querySelector('input[name="amount"]:checked');
    const amount = customAmountInput.value !== ""
        ? Number(customAmountInput.value)
        : Number(selectedAmount?.value);

    if (!Number.isFinite(amount) || amount <= 0) {
        donationResult.textContent = "Enter a donation amount greater than zero.";
        customAmountInput.focus();
        return;
    }

    const formattedAmount = new Intl.NumberFormat("en-ZA", {
        style: "currency",
        currency: "ZAR"
    }).format(amount);

    donationResult.textContent = `${formattedAmount} selected. No payment has been processed. Please use Amakhaya's official contact details to arrange your donation.`;
});