const pageImages = Array.from(document.querySelectorAll(".page img"));
const lightbox = document.querySelector("#image-lightbox");
const lightboxImage = lightbox.querySelector(".lightbox-image");
const lightboxCaption = lightbox.querySelector(".lightbox-caption");
const closeButton = lightbox.querySelector(".lightbox-close");
const previousButton = lightbox.querySelector(".lightbox-previous");
const nextButton = lightbox.querySelector(".lightbox-next");
let activeImageIndex = 0;

function showImage(index) {
    activeImageIndex = (index + pageImages.length) % pageImages.length;
    const sourceImage = pageImages[activeImageIndex];

    lightboxImage.src = sourceImage.src;
    lightboxImage.alt = sourceImage.alt;
    lightboxCaption.textContent = `${sourceImage.alt} (${activeImageIndex + 1} of ${pageImages.length})`;
}

pageImages.forEach((image, index) => {
    image.addEventListener("click", () => {
        showImage(index);
        lightbox.showModal();
        closeButton.focus();
    });
});

closeButton.addEventListener("click", () => lightbox.close());
previousButton.addEventListener("click", () => showImage(activeImageIndex - 1));
nextButton.addEventListener("click", () => showImage(activeImageIndex + 1));

lightbox.addEventListener("click", (event) => {
    if (event.target === lightbox) {
        lightbox.close();
    }
});

lightbox.addEventListener("keydown", (event) => {
    if (event.key === "ArrowLeft") {
        showImage(activeImageIndex - 1);
    } else if (event.key === "ArrowRight") {
        showImage(activeImageIndex + 1);
    }
});