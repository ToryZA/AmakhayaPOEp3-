//Change log changed-font to "Shadow into light"
updated contact page,some changes were not made to git as i logged in after making some changes 
//made the footer short as some phones had over lapping footers 

//added to stories page added context of young man who was once an orphan and now helps around the orphange will add more stories
//added javascript  
// The donations page now lets visitors select a preset amount (R50, R100, R250, or R500) or enter a custom amount. When they press Continue, JavaScript checks the amount and displays it formatted as South African rand.
//add a lightbox so the users can interact with the webpage 
//i added SEO tags i used from youtube and w3school 

refrences 
-https://github.com/stripe-archive/stripe-payments-demo.git
